/*打开评论的二级模态框*/
		function showComment() {
			$("#show-comment-detail-page").modal("show");
		}

		/*打开收藏二级模态框*/
		$(function() {
			$("#creat-shoucang").click(function() {

				$("#creat-shoucang-page").modal("show");
			});

		});

		$(function() {

			/*打开编辑区*/
			$('#Write-answer').click(function() {
				$(this).attr("disabled", "disabled");
				$('#editor-form').css("display", "block"); //显示form表单
				var myEditor = null;
				ClassicEditor
					.create(document.querySelector('#editor'), {
						ckfinder: {

							uploadUrl: "http://localhost/test/upload1.do"

						},
						toolbar: {
							items: [
								'heading',
								'|',
								'bold',
								'fontBackgroundColor',
								'removeFormat',
								'italic',
								'link',
								'bulletedList',
								'numberedList',
								'|',
								'indent',
								'outdent',
								'|',
								'imageUpload',
								'blockQuote',
								'insertTable',
								'undo',
								'redo'
							]
						},
						language: 'zh-cn',
						image: {
							toolbar: [
								'imageTextAlternative',
								'imageStyle:full',
								'imageStyle:side'
							]
						},
						table: {
							contentToolbar: [
								'tableColumn',
								'tableRow',
								'mergeTableCells'
							]
						},
						licenseKey: '',

					})
					.then(editor => {
						myEditor = editor;
					})
					.catch(error => {
						console.error(error);
					});
			});

		});