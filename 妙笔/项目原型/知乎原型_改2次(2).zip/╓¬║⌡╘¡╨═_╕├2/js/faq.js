$('#faqul li ').click(function() {
	var f = this;
	$('#faqul li ').each(function() {
		this.className = this == f ? 'clicka' : 'noneclick';
		this == f ? this.style.border = "" : this.style.border = 'none'
	});
});
$('#faqul2 li ').click(function() {
	var f = this;
	$('#faqul2 li ').each(function() {
		this.className = this == f ? 'clicka' : 'noneclick';
		this == f ? this.style.border = "" : this.style.border = 'none'
	});
});
$(document).ready(function() {
	$("#faqa").click(function() {
		$("#faqdiv1").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa1").click(function() {
		$("#faqdiv2").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa2").click(function() {
		$("#faqdiv3").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa3").click(function() {
		$("#faqdiv4").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa4").click(function() {
		$("#faqdiv5").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa5").click(function() {
		$("#faqdiv6").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa6").click(function() {
		$("#faqdiv7").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa7").click(function() {
		$("#faqdiv8").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa8").click(function() {
		$("#faqdiv9").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa9").click(function() {
		$("#faqdiv10").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa10").click(function() {
		$("#faqdiv11").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#faqa11").click(function() {
		$("#faqdiv12").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo1").click(function() {
		$("#hang1").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo2").click(function() {
		$("#hang2").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo3").click(function() {
		$("#hang3").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo4").click(function() {
		$("#hang4").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo5").click(function() {
		$("#hang5").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo6").click(function() {
		$("#hang6").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo7").click(function() {
		$("#hang7").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo8").click(function() {
		$("#hang8").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo9").click(function() {
		$("#hang9").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo10").click(function() {
		$("#hang10").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo11").click(function() {
		$("#hang11").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo12").click(function() {
		$("#hang12").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo13").click(function() {
		$("#hang13").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo14").click(function() {
		$("#hang14").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo15").click(function() {
		$("#hang15").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo16").click(function() {
		$("#hang16").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo17").click(function() {
		$("#hang17").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo18").click(function() {
		$("#hang18").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo19").click(function() {
		$("#hang19").slideToggle("slow");
	});
});

$(document).ready(function() {
	$("#guo20").click(function() {
		$("#hang20").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo21").click(function() {
		$("#hang21").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo22").click(function() {
		$("#hang22").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo23").click(function() {
		$("#hang23").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo24").click(function() {
		$("#hang24").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo25").click(function() {
		$("#hang25").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo26").click(function() {
		$("#hang26").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo27").click(function() {
		$("#hang27").slideToggle("slow");
	});
});
$(document).ready(function() {
	$("#guo28").click(function() {
		$("#hang28").slideToggle("slow");
	});
});
