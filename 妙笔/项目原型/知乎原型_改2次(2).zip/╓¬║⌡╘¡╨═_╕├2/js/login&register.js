function userlogin() {
	$("#userlogin").css("border-bottom", "none")
	$("#userlogin").css("font-weight", "normal")
	$("#registerlogin").css("font-weight", "600")
	$("#registerlogin").css("border-bottom", "2px solid #0084ff")
	var a = document.getElementById("userlogin");
	a.innerHTML = "账户名登录"
	$("#formlogin").html('');
	$("#formlogin").load("formTwo.html")

}

function registerlogin() {
	$("#registerlogin").css("border-bottom", "none")
	$("#registerlogin").css("font-weight", "normal")
	$("#userlogin").css("font-weight", "600")
	$("#userlogin").css("border-bottom", "2px solid #0084ff")
	$("#formlogin").html('');
	$("#formlogin").load("formOne.html")
}
$(function() {
	var slider = new SliderUnlock("#slider", {
		successLabelTip: "验证成功"
	}, function() {
		alert("验证成功,即将跳转至百度");
		window.location.href = "http://www.baidu.com"
	});
	slider.init();
})
var password = document.getElementById("password");
//密码小眼睛
function eye() {
	if(password.type == "password") {
		password.type = "text";
	} else {
		password.type = "password";
	}
}

function checkUsername() {
	//获取用户名的值
	var username = $("#username").val();
	//定义正则表达式
	var reg_username = /^\w{8,20}$/;
	//进行判断给出提示信息
	var flag = reg_username.test(username);
	if(flag) {
		//用户名合法，去掉红色边框
		$("#username").css("border", "");

	} else {
		//用户名非法,加一个红色边框
		$("#username").css("border", "1px solid red");
	}
	return flag;
}