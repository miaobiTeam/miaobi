/*判断滚动条的位置*/
document.onscroll = function() {
	var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
	var cHeight = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
	var oDiv = document.getElementById('issue');
	var navigation = document.getElementById('navigation');
	if(scrollTop > (oDiv.offsetTop - cHeight))
		//  alert('触发了')

		//if(scrollTop > (navigation.offsetTop - cHeight))
		document.getElementById("dnhd").style.boxShadow = "10px 10px 20px #A8A8A8"
	document.getElementById("dnhd").style.transition = "all 1s"
}

function scrollBottomOrTop() {
	var clients = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
	var scrollTop = document.documentElement.scrollTop;
	// 这里存在兼容问题，会把body当成div来处理，如果用document.body.scrollHeight就得不到正确的高度，用body时需要把doctype后面的html去掉
	// 这里没用body，而是用到documentElement
	var wholeHeight = document.documentElement.scrollHeight;
	if(clients + scrollTop >= wholeHeight) {
		//            	alert("我到底部了");                
		// 在实际应用中可以通过请求后台获取下一页的数据，然后显示到当前位置，就能达到按页加载的效果。
	}
	if(scrollTop == 0) {
		//              alert("我到顶部了");
		document.getElementById("dnhd").style.boxShadow = "none"
		document.getElementById("dnhd").style.transition = "all 1s"
	}
}
window.onscroll = scrollBottomOrTop;

/*4个模块的隐藏和显示*/
function hide() {
	document.getElementById("allissue").style.display = "block"
	document.getElementById("allissue2").style.display = "none"
	document.getElementById("allissue3").style.display = "none"
	document.getElementById("allissue4").style.display = "none"
	//点击不同模块颜色及背景的改变

	document.getElementById("sentiment").style.color = "#0084ff"
	document.getElementById("backSentiment").style.background = "rgba(0,132,255,.08)"
	document.getElementById("potential").style.color = "black"
	document.getElementById("backSentiment2").style.background = "#E0E0E0"
	document.getElementById("new").style.color = "black"
	document.getElementById("backSentiment3").style.background = "#E0E0E0"
	document.getElementById("person").style.color = "black"
	document.getElementById("backSentiment4").style.background = "#E0E0E0"

}

function hide2() {
	document.getElementById("allissue").style.display = "none"
	document.getElementById("allissue3").style.display = "none"
	document.getElementById("allissue4").style.display = "none"
	document.getElementById("allissue2").style.display = "block"
	//点击不同模块颜色及背景的改变
	document.getElementById("potential").style.color = "#0084ff"
	document.getElementById("backSentiment2").style.background = "rgba(0,132,255,.08)"
	document.getElementById("sentiment").style.color = "black"
	document.getElementById("backSentiment").style.background = "#E0E0E0"
	document.getElementById("new").style.color = "black"
	document.getElementById("backSentiment3").style.background = "#E0E0E0"
	document.getElementById("person").style.color = "black"
	document.getElementById("backSentiment4").style.background = "#E0E0E0"
}

function hide3() {
	document.getElementById("allissue").style.display = "none"
	document.getElementById("allissue2").style.display = "none"
	document.getElementById("allissue4").style.display = "none"
	document.getElementById("allissue3").style.display = "block"
	//点击不同模块颜色及背景的改变
	document.getElementById("new").style.color = "#0084ff"
	document.getElementById("backSentiment3").style.background = "rgba(0,132,255,.08)"
	document.getElementById("sentiment").style.color = "black"
	document.getElementById("backSentiment").style.background = "#E0E0E0"
	document.getElementById("potential").style.color = "black"
	document.getElementById("backSentiment2").style.background = "#E0E0E0"
	document.getElementById("person").style.color = "black"
	document.getElementById("backSentiment4").style.background = "#E0E0E0"

}

function hide4() {
	document.getElementById("allissue").style.display = "none"
	document.getElementById("allissue2").style.display = "none"
	document.getElementById("allissue3").style.display = "none"
	document.getElementById("allissue4").style.display = "block"
	//点击不同模块颜色及背景的改变
	document.getElementById("person").style.color = "#0084ff"
	document.getElementById("backSentiment4").style.background = "rgba(0,132,255,.08)"
	document.getElementById("sentiment").style.color = "black"
	document.getElementById("backSentiment").style.background = "#E0E0E0"
	document.getElementById("potential").style.color = "black"
	document.getElementById("backSentiment2").style.background = "#E0E0E0"
	document.getElementById("new").style.color = "black"
	document.getElementById("backSentiment3").style.background = "#E0E0E0"
}
/*关注*/
function attention() {
	document.getElementById("issue_attention").style.visibility = "hidden"
	document.getElementById("issue-attention").style.visibility = "visible"
}

function attention2() {
	document.getElementById("issue_attention").style.visibility = "visible"
	document.getElementById("issue-attention").style.visibility = "hidden"
}
/*关注*/
function attention3() {
	document.getElementById("issue_attention2").style.visibility = "hidden"
	document.getElementById("issue-attention2").style.visibility = "visible"
}

function attention4() {
	document.getElementById("issue_attention2").style.visibility = "visible"
	document.getElementById("issue-attention2").style.visibility = "hidden"
}
/*添加*/
function add() {
	document.getElementById("issue_add").style.visibility = "hidden"
	document.getElementById("issue-add").style.visibility = "visible"
}

function add2() {
	document.getElementById("issue_add").style.visibility = "visible"
	document.getElementById("issue-add").style.visibility = "hidden"
}
/*添加*/
function add3() {
	document.getElementById("issue_add2").style.visibility = "hidden"
	document.getElementById("issue-add2").style.visibility = "visible"
}

function add4() {
	document.getElementById("issue_add2").style.visibility = "visible"
	document.getElementById("issue-add2").style.visibility = "hidden"
}

/*关闭按钮*/
function over() {
	document.getElementById("issue").style.display = "none"
}

function over2() {
	document.getElementById("issue2").style.display = "none"
}

function over3() {
	document.getElementById("issue3").style.display = "none"
}

function over4() {
	document.getElementById("issue4").style.display = "none"
}