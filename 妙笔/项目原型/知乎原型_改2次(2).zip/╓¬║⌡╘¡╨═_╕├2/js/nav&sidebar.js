$(document).ready(function() {
	$("#navinput").focus(function() {
		$("#navbutton2").animate({
			width: '0px',
			height: '0px',
			opacity: '0'
		});
	});
	$("#navinput").blur(function() {
		$("#navbutton2").animate({
			width: '60px',
			height: '36px',
			opacity: '1'
		});
	});
});
$(function() {
	var scrollFunc = function(e) {
		var direct = 0;
		e = e || window.event;
		var scroll = $(this).scrollTop(); //当前滚动高度

		if(e.wheelDelta) { //判断浏览器类型,IE,谷歌
			if(scroll == 0) {

				return;
			} else if(e.wheelDelta > 0) { //当向上滚动时,执行下面事件
				console.log("向上滚动");
				//处理逻辑代码
				$(".haoren1").css("display", "none");
				$(".haoren").addClass("navbar-fixed-top");
				$(".haoren1").removeClass("navbar-fixed-top");
			}

			if(e.wheelDelta < 0) { //当向下滚动时,执行下面事件
				console.log("向下滚动");
				//处理逻辑代码
				$(".haoren1").css("display", "block");
				$(".haoren1").addClass("navbar-fixed-top");
				$(".haoren").removeClass("navbar-fixed-top");
			}
		} else if(e.detail) { //判断浏览器类型,火狐
			if(scroll == 0) {
				return;
			} else if(e.detail > 0) {
				console.log("向上滚动");
				//处理逻辑代码
			}

			if(e.detail < 0) {
				console.log("向下滚动");
				//处理逻辑代码
			}
		}

	}

	//给页面绑定事件监听器
	if(document.addEventListener) {
		console.log("绑定事件监听器");
		document.addEventListener('DOMMouseScroll', scrollFunc, false);
	}
	//滚动滑轮触发上面定义的方法
	window.onmousewheel = document.onmousewheel = scrollFunc;

});