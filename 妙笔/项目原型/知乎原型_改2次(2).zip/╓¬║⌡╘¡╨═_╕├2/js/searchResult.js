$(function() {

			$("#content").load('./search/zhonghe.html');

			$('#zhonghe').click(function() {
				//给自己添加active,删除其它元素的active
				$(this).addClass("active").siblings().removeClass("active");
				$("#content").load('./search/zhonghe.html');
				$(".haoren").addClass("navbar-fixed-top");
				$(".haoren1").removeClass("navbar-fixed-top");
			});

			$('#yonghu').click(function() {
				//给自己添加active,删除其它元素的active
				$(this).addClass("active").siblings().removeClass("active");
				$("#content").load('./search/yonghu.html');
				$(".haoren").addClass("navbar-fixed-top");
				$(".haoren1").removeClass("navbar-fixed-top");
			});

			$('#huati').click(function() {
				//给自己添加active,删除其它元素的active
				$(this).addClass("active").siblings().removeClass("active");
				$("#content").load('./search/huati.html');
				$(".haoren").addClass("navbar-fixed-top");
				$(".haoren1").removeClass("navbar-fixed-top");

			});

			$('#zhuanlan').click(function() {
				//给自己添加active,删除其它元素的active
				$(this).addClass("active").siblings().removeClass("active");
				$("#content").load('./search/zhuanlan.html');
				$(".haoren").addClass("navbar-fixed-top");
				$(".haoren1").removeClass("navbar-fixed-top");
			});

		});

		$(function() {
			var scrollFunc = function(e) {
				var direct = 0;
				e = e || window.event;
				var scroll = $(this).scrollTop(); //当前滚动高度

				if(e.wheelDelta) { //判断浏览器类型,IE,谷歌
					if(scroll == 0) {

						return;
					} else if(e.wheelDelta > 0) { //当向上滚动时,执行下面事件
						console.log("向上滚动");
						//处理逻辑代码
						$(".haoren").addClass("navbar-fixed-top");
						$(".haoren1").removeClass("navbar-fixed-top");

					}

					if(e.wheelDelta < 0) { //当向下滚动时,执行下面事件
						console.log("向下滚动");
						//处理逻辑代码
						$(".haoren1").addClass("navbar-fixed-top");
						$(".haoren").removeClass("navbar-fixed-top");
					}
				} else if(e.detail) { //判断浏览器类型,火狐
					if(scroll == 0) {
						return;
					} else if(e.detail > 0) {
						console.log("向上滚动");
						//处理逻辑代码
					}

					if(e.detail < 0) {
						console.log("向下滚动");
						//处理逻辑代码
					}
				}

			}

			//给页面绑定事件监听器
			if(document.addEventListener) {
				console.log("绑定事件监听器");
				document.addEventListener('DOMMouseScroll', scrollFunc, false);
			}
			//滚动滑轮触发上面定义的方法
			window.onmousewheel = document.onmousewheel = scrollFunc;

		});