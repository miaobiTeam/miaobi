function homepage(){
	$("#list").load("CreatorCenterPage/homepage.html");
}
function issue(){
	$("#list").load("CreatorCenterPage/issue.html");
}
function contentanalysis(){
	$("#list").load("CreatorCenterPage/contentanalysis.html");
}
function userinfo(){
	$("#list").load("CreatorCenterPage/userinfo.html");
}
function faq(){
	$("#list").load("CreatorCenterPage/faq.html");
}
function levelofgrowth(){
	$("#list").load("CreatorCenterPage/levelofgrowth.html");
}
function uploadvideo(){
	$("#list").load("CreatorCenterPage/uploadvideo.html");
}
function createlist(){
	$("#list").load("CreatorCenterPage/createlist.html");
}
function recommendation(){
	$("#list").load("CreatorCenterPage/recommendation.html");
}
function generalize(){
	$("#list").load("CreatorCenterPage/generalize.html");
}
function admire(){
	$("#list").load("CreatorCenterPage/admire.html");
}
function zhihulive(){
	$("#list").load("CreatorCenterPage/zhihulive.html");
}
function brand(){
	$("#list").load("CreatorCenterPage/brand.html");
}
function compere(){
	$("#list").load("CreatorCenterPage/compere.html");
}
function specialtest(){
	$("#list").load("CreatorCenterPage/specialtest.html");
}
function rights(){
	$("#list").load("CreatorCenterPage/rights.html");
}