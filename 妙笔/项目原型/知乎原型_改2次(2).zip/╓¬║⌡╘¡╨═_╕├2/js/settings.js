
	/*侧边栏*/
	$('#vtab a:first').tab('show');//初始化显示哪个tab
    	$('#vtab a').click(function(e) {
        e.preventDefault();//阻止a链接的跳转行为
        $(this).tab('show');//显示当前选中的链接及关联的content
    });
    
    /* 更改nav标签字体颜色*/
   	$("a").click(function () {
   		//清除,非当前点击标签的样式
        clearAClass();
        $(this).addClass("a_color");
   });
   
    $("li").click(function () {
   		//清除,非当前点击标签的样式
        clearLiClass();
        $(this).addClass("li_bgcolor");
   });
   
   function clearAClass() {
        $("a").each(function () {
            $(this).removeClass("a_color");
        });
   };
   function clearLiClass() {
        $("li").each(function () {
            $(this).removeClass("li_bgcolor");
        });
   };
   
   //邮箱发送验证码
	$("#codeBtn").click(function(){
		$(".Modal-body .Modal-email .Modal-email-verify .Modal-email-verify-submit")
		.addClass("focus").css("pointer-events","none");//移除hover样式
		$(".Modal-body .Modal-email .Modal-email-verify .Modal-email-verify-submit")
		.css("color","#C0C0C0");//添加样式
		curCount = count;　　 //设置button效果，开始计时  
		$("#codeBtn").attr("disabled", "true");
		$("#codeBtn").val(curCount + "s后重发");
		InterValObj = window.setInterval(SetRemainTime, 1000); //启动计时器，1秒执行一次  
		$.ajax({
	    	type:"get",
	    });
	});
	var InterValObj; //timer变量，控制时间  
	var count = 60; //间隔函数，1秒执行  
	var curCount; //当前剩余秒数  
	//timer处理函数  
	function SetRemainTime() {
		if(curCount == 0) {
			window.clearInterval(InterValObj); //停止计时器  
			$("#codeBtn").removeAttr("disabled"); //启用按钮  
			$("#codeBtn").val("重新发送验证码");
		} else {
			curCount--;
			$("#codeBtn").val(curCount + "s后重发");
		}
	};
	
	/*下拉框*/
	$("#hiddenSelect").selectpicker('refresh');     //完成需要的功能后 手动刷新对应的select
	$("#hiddenSelect").selectpicker('val',2);        //设置指定选中的值
	
	/*待-优化代码*/
	/*私信*/
	function PrivateLetter(){
		if(document.getElementById("PrivateLetterShowBtn").innerHTML=="编辑"){
			document.getElementById("PrivateLetterShowBtn").innerHTML="收起";
			document.getElementById("PrivateLetterItems").style.display="block";
			$('#PrivateLetter').removeClass('change-other-settings');
			$('#PrivateLetter').addClass('hidden-other-settings');
		}else{
			document.getElementById("PrivateLetterShowBtn").innerHTML="编辑";
			document.getElementById("PrivateLetterItems").style.display="none";
			$('#PrivateLetter').removeClass('hidden-other-settings');
		}
	}
	/*关注*/
	function Attention(){
		if(document.getElementById("AttentionShowBtn").innerHTML=="编辑"){
			document.getElementById("AttentionShowBtn").innerHTML="收起";
			document.getElementById("AttentionItemFirst").style.display="block";
			document.getElementById("AttentionItemSecond").style.display="block";
			document.getElementById("AttentionItemThirdly").style.display="block";
			document.getElementById("AttentionItemFourthly").style.display="block";
			document.getElementById("AttentionItemFifth").style.display="block";
			document.getElementById("AttentionItemFifth").style.display="block";
			document.getElementById("AttentionItemSixth").style.display="block";
			document.getElementById("AttentionItemLast").style.display="block";
			$('#Attention').removeClass('change-other-settings').addClass('hidden-other-settings');
		}else{
			document.getElementById("AttentionShowBtn").innerHTML="编辑";
			document.getElementById("AttentionItemFirst").style.display="none";
			document.getElementById("AttentionItemSecond").style.display="none";
			document.getElementById("AttentionItemThirdly").style.display="none";
			document.getElementById("AttentionItemFourthly").style.display="none";
			document.getElementById("AttentionItemFifth").style.display="none";
			document.getElementById("AttentionItemFifth").style.display="none";
			document.getElementById("AttentionItemSixth").style.display="none";
			document.getElementById("AttentionItemLast").style.display="none";
			$('#Attention').removeClass('hidden-other-settings').addClass('change-other-settings');
		}
	}
	/*赞赏*/
	function Admire(){
		if(document.getElementById("AdmireShowBtn").innerHTML=="编辑"){
			document.getElementById("AdmireShowBtn").innerHTML="收起";
			document.getElementById("AdmireItemFirst").style.display="block";
			document.getElementById("AdmireItemSecond").style.display="block";
			document.getElementById("AdmireItemThirdly").style.display="block";
			document.getElementById("AdmireItemLast").style.display="block";
			$('#Admire').removeClass('change-other-settings').addClass('hidden-other-settings');
		}else{
			document.getElementById("AdmireShowBtn").innerHTML="编辑";
			document.getElementById("AdmireItemFirst").style.display="none";
			document.getElementById("AdmireItemSecond").style.display="none";
			document.getElementById("AdmireItemThirdly").style.display="none";
			document.getElementById("AdmireItemLast").style.display="none";
			$('#Admire').removeClass('hidden-other-settings').addClass('change-other-settings');
		}
	}
	/*评论*/
	function Comment(){
		if(document.getElementById("CommentShowBtn").innerHTML=="编辑"){
			document.getElementById("CommentShowBtn").innerHTML="收起";
			document.getElementById("CommentItemFirst").style.display="block";
			document.getElementById("CommentItemSecond").style.display="block";
			document.getElementById("CommentItemLast").style.display="block";
			$('#Comment').removeClass('change-other-settings').addClass('hidden-other-settings');
		}else{
			document.getElementById("CommentShowBtn").innerHTML="编辑";
			document.getElementById("CommentItemFirst").style.display="none";
			document.getElementById("CommentItemSecond").style.display="none";
			document.getElementById("CommentItemLast").style.display="none";
			$('#Comment').removeClass('hidden-other-settings').addClass('change-other-settings');
		}
	}

	/*话题黑名单*/
	function TopicBlacklist(){
		if(document.getElementById("TopicBlacklistShowBtn").innerHTML=="编辑"){
			document.getElementById("TopicBlacklistShowBtn").innerHTML="收起";
			document.getElementById("TopicBlacklistItemFirst").style.display="block";
			document.getElementById("TopicBlacklistItemLast").style.display="block";
			document.getElementById("shielding-blacklist").style.display="none";
			$('#TopicBlacklist').removeClass('change-other-settings').addClass('hidden-other-settings');
		}else{
			document.getElementById("TopicBlacklistShowBtn").innerHTML="编辑";
			document.getElementById("TopicBlacklistItemFirst").style.display="none";
			document.getElementById("TopicBlacklistItemLast").style.display="none";
			document.getElementById("shielding-blacklist").style.display="block";
			$('#TopicBlacklist').removeClass('hidden-other-settings').addClass('change-other-settings');
		}
	}
	
	/*话题黑名单*/
	function HidingPersonalInformation(){
		if(document.getElementById("HidingPersonalInformationShowBtn").innerHTML=="编辑"){
			document.getElementById("HidingPersonalInformationShowBtn").innerHTML="收起";
			document.getElementById("HidingPersonalInformationItemLast").style.display="block";
	        $('#HidingPersonalInformationItemLast').removeClass('change-other-settings').addClass('hidden-other-settings');
	        $('#HidingPersonalInformationItemFirst').removeClass('change-other-settings').addClass('hidden-other-settings');
			$('#HidingPersonalInformation').removeClass('change-other-settings').addClass('hidden-other-settings');
		}else{
			document.getElementById("HidingPersonalInformationShowBtn").innerHTML="编辑";
			document.getElementById("HidingPersonalInformationItemLast").style.display="none";
			$('#HidingPersonalInformation').removeClass('hidden-other-settings').addClass('change-other-settings');
			$('#HidingPersonalInformationItemFirst').removeClass('hidden-other-settings').addClass('change-other-settings');
		}
	}
	/*开关选项*/
	$('[name="PersonalDetails"]').bootstrapSwitch({  
	        onText:"ON",  
	        offText:"OFF",  
	        onColor:"success",  
	        offColor:"danger",  
	        size:"small",  
        	onSwitchChange:function(event,state){  
	            if(state==true){  
	               console.log('哈哈');
	            }else{  
	               console.log('已关闭');  
	            }  
	        }  
		});